function loadMainText(jsonObj) {
    $('#coke-main-title').html(jsonObj.mainText.title);
    $('#coke-main-subtitle').html(jsonObj.mainText.subTitle);
    $('#coke-main-mainbody').html(jsonObj.mainText.mainBody);
}

function loadProductMainText(jsonObj, prod, index) {
    $('#' + prod + "-main-title").html(jsonObj.prodMainText[index].title);
    $('#' + prod + "-main-subtitle").html(jsonObj.prodMainText[index].subTitle);
    $('#' + prod + "-main-mainbody").html(jsonObj.prodMainText[index].mainBody);
}

function loadProductParameter(jsonObj, prod, index) {
    $('#' + prod + "-energy").html(jsonObj.prodParameters[index].energy);
    $('#' + prod + "-nutrition").html(jsonObj.prodParameters[index].nutrition);
}

function loadProductDesigner(jsonObj, prod, index) {
    $('#designer-' + prod + "-name").html(jsonObj.designers[index].name);
    $('#designer-' + prod + "-comment").html(jsonObj.designers[index].comment);
}

$(document).ready(function () {
    $.getJSON("./application/model/data.php",
        function (jsonObj) {
            loadMainText(jsonObj);
            loadProductMainText(jsonObj, "cola", 0);
            loadProductMainText(jsonObj, "tonic", 1);
            loadProductMainText(jsonObj, "fanta", 2);
            loadProductParameter(jsonObj, "cola", 0);
            loadProductParameter(jsonObj, "tonic", 1);
            loadProductParameter(jsonObj, "fanta", 2);
            loadProductDesigner(jsonObj, "cola", 0);
            loadProductDesigner(jsonObj, "tonic", 1);
            loadProductDesigner(jsonObj, "fanta", 2);
        }
    );
    $('#home').show();
    $('#products-group').show();
    $('#model-viewer').hide();
    $('#designer').hide();
})