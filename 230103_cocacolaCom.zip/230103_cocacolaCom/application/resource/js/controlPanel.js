function switchModel(model) {
    switch (model) {
        case 'home':
            $('#home').show();
            $('#products-group').show();
            $('#model-viewer').hide();
            $('#designer').hide();
            break;
        case 'Cola':
            $('#home').hide();
            $('#products-group').hide();
            $('#model-viewer').show();
            $('#cola-parameter').show();
            $('#tonic-parameter').hide();
            $('#fanta-parameter').hide();
            $('#designer').show();
            $('#designer-cola').show();
            $('#designer-tonic').hide();
            $('#designer-fanta').hide();
            $('#model_selector').attr('whichChoice', '0');
            console.log('hide home');
            break;
        case 'Tonic':
            $('#home').hide();
            $('#products-group').hide();
            $('#model-viewer').show();
            $('#cola-parameter').hide();
            $('#tonic-parameter').show();
            $('#fanta-parameter').hide();
            $('#designer').show();
            $('#designer-cola').hide();
            $('#designer-tonic').show();
            $('#designer-fanta').hide();
            $('#model_selector').attr('whichChoice', '1');
            break;
        case 'Fanta':
            $('#home').hide();
            $('#products-group').hide();
            $('#model-viewer').show();
            $('#cola-parameter').hide();
            $('#tonic-parameter').hide();
            $('#fanta-parameter').show();
            $('#designer').show();
            $('#designer-cola').hide();
            $('#designer-tonic').hide();
            $('#designer-fanta').show();
            $('#model_selector').attr('whichChoice', '2');
            break;
        default:
            break;
    }
    $('#model-title').html(model);
    viewFromCamera('Front');
}

function modelResolve() {
    switch ($("#model_selector").attr("whichChoice")) {
        case '0':
            return 'cola';
        case '1':
            return 'tonic';
        case '2':
            return 'fanta';
        default:
            break;
    }
}

function viewFromCamera(direction) {
    model = modelResolve();
    console.log(model + '__' + direction);
    document.getElementById(model + '__' + direction).setAttribute('set_bind', 'true');
}

isRunning = false
function switchAnimationState() {
    model = modelResolve();
    isRunning = !isRunning;
    document.getElementById(model + '__' + 'AnimationTimer').setAttribute('enabled', isRunning.toString());
    console.log(document.getElementById(model + '__' + 'AnimationTimer'));
    if (isRunning) {
        $("#animation-trigger").html('Stop');
    } else {
        $("#animation-trigger").html('Start');
    }
}


function switchLight(model, lightType, elementId, x3dId) {
    flag = $('#' + model + '__' + lightType).attr(x3dId);

    flag = (flag == 'true') ? 'false' : 'true';

    $('#' + model + '__' + lightType).attr(x3dId, flag);
    if (flag == 'true') {
        $('#' + elementId).removeClass('fa-toggle-off');
        $('#' + elementId).addClass('fa-toggle-on');
    } else {
        $('#' + elementId).removeClass('fa-toggle-on');
        $('#' + elementId).addClass('fa-toggle-off');
    }

    console.log(model + '__' + lightType);
}

function recallUIElement() {

}

function switchDirectLight() {
    model = modelResolve();
    switchLight(model, 'Direct', 'directlight-sw', 'on');
}

function switchSpotLight() {
    model = modelResolve();
    switchLight(model, 'Spot', 'spotlight-sw', 'on');
}

function switchPointLight() {
    model = modelResolve();
    switchLight(model, 'Point', 'pointlight-sw', 'on');
}

