<?php
// set data model here
class Model
{
    public function __construct()
    {

    }

    public function fetchPageTextData()
    {
        return array(
            'helloWorld' => 'this is something about this page'
        );
    }
}

?>